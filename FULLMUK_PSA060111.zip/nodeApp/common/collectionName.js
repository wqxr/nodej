/**
 * 数据库的collection名称
 */
const collectionName = {
    "ProductionDetail":"ProductionDetail",
    "Saveconfig":"saveconfig",
    "pcbcount":"pcbcount",
    "machineConfig":"machineConfig",
    "precision":"precision",
    "checkinfodetail":"checkinfodetail",
    "productdetail":"productdetial",
    "setpressInfo":"setpressInfo",
    "pressdata":"pressdata",
    "producttotal":"producttotal",
    "eachhourproduct":"eachhourproduct",
   
};

module.exports = collectionName;