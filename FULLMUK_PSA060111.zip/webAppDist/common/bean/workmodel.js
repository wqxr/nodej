"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var workModel = /** @class */ (function () {
    function workModel() {
    }
    return workModel;
}());
exports.workModel = workModel;
//# sourceMappingURL=workmodel.js.map