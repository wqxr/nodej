"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var productDetail = /** @class */ (function () {
    function productDetail() {
    }
    return productDetail;
}());
exports.productDetail = productDetail;
//# sourceMappingURL=productdetail.js.map