"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var countInfoService = /** @class */ (function () {
    function countInfoService() {
    }
    countInfoService.prototype.updateheadInfo = function (data, datainfo) {
        // data.
        //   data.goodKeyBoard=datainfo.goodKeyBoard;
        //   data.stationCycle=datainfo.stationCycle;
        //   data.UPH=datainfo.UPH;
        //   data.badKeyBoard=datainfo.badKeyBoard;
        //   data.goodPer=Math.round(datainfo.goodKeyBoard/(datainfo.goodKeyBoard+datainfo.badKeyBoard)*100);
        //   data.timeConsume=datainfo.timeConsume;
        //   data.headdetail.push(data.finishKeyBoard,data.goodKeyBoard,data.stationCycle,data.UPH,data.badKeyBoard,data.goodPer,data.timeConsume);
        //   console.log(data.headdetail);
    };
    countInfoService = __decorate([
        core_1.Injectable()
    ], countInfoService);
    return countInfoService;
}());
exports.countInfoService = countInfoService;
//# sourceMappingURL=countinfoService.js.map