"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var headerinfo_1 = require("../../common/bean/headerinfo");
var Assembling_1 = require("../../common/bean/Assembling");
var footerInfo_1 = require("../footerInfo/footerInfo");
var headerinfo_2 = require("../headerinfo/headerinfo");
var aside_1 = require("../aside/aside");
var centerInfo_1 = require("../centerInfo/centerInfo");
var logPanel_1 = require("../logPanel/logPanel");
var login_panel_1 = require("../loginPanel/login.panel");
var dialog = nodeRequire('electron').remote.dialog;
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var AppComponent = /** @class */ (function () {
    function AppComponent(_ngZone, ipcService) {
        this.isShow = true;
        this.configShow = true;
        this.isUseShow = false;
        this.logshow = true;
        this.pointshow = true;
        this.maskshow = true;
        this.fullScreenFlag = false;
        this.configinfo = {
            configname: "",
            configid: "",
            version: "",
            planCT: "",
            line: "",
            stationId: "",
        };
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.ipcService = ipcService;
        //  this.assemblingService = assemblingService;
        //this.logs = [];
        //  this.ctnumber = [];
        this.pressSn = "";
        this.press = [];
        this.machineStatus = 0;
        this.closemsg = true;
        this.closewindow = true;
        this.ctboolean = true;
        this.loginStatus = {
            isLogin: false,
            role: "登录",
        };
        this.goodtotal = 0;
        this.ctendtime = 0;
        this.failtotal = 0;
        this.planproductnum = 0;
        this.successinfo = "";
    }
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.headerinfo = new headerinfo_1.Headerinfo();
        this.assembling = new Assembling_1.Assembling();
        this.headerinfo.Acycletime = 0;
        this.headerinfo.CT = 0;
        this.headerinfo.goodnumber = 0;
        this.headerinfo.badnumber = 0;
        this.headerinfo.goodprobability = 0;
        this.headerinfo.totalnumber = 0;
        this.ipcService.on("opsStatus", function (data) {
            _this._ngZone.run(function () {
                _this.machineStatus = data.data.status;
                // console.info(this.machineStatus);
                if (_this.machineStatus === 100) {
                    _this.ipcService.send("windowclose", {});
                }
                _this.asidecomponent.getmachineStatus(_this.machineStatus);
                _this.headerinfomation.getStatus(data.data.status);
                _this.keycapsDetail.changestatus(data.data.status);
            });
        });
        // this.ipcService.on("page_readyResult", (data) => {//页面一加载
        //   this._ngZone.run(() => {
        //     //this.keycapsComponent.readconfig(data.data);   
        //     // this.asidecomponent.readmachineconfig(data.data);
        //     // console.info(data.data);
        //     this.assemblingService.onloadProduct(this.assembling, data.data);
        //   })
        // })
        // this.ipcService.on("onloadProduct", (data) => {//Tray盘计数
        //   this._ngZone.run(() => {
        //     //this.assemblingService.onloadProduct(this.assembling, data.data);
        //   })
        // })
        this.ipcService.on("totalproduct", function (data) {
            _this._ngZone.run(function () {
                _this.headerinfo.goodnumber = data.data.goodproduct;
                _this.headerinfo.badnumber = data.data.failproduct;
                _this.headerinfo.totalnumber = data.data.total;
            });
        });
        this.ipcService.on("scanResult", function (data) {
            _this._ngZone.run(function () {
                _this.keycapsComponent.clearimg();
                if (data.data.PCBSN !== "" && data.data.PCBSN != undefined) {
                    _this.headerinfo.newSN = data.data.PCBSN;
                    _this.AstartTime = Date.now();
                }
                else {
                    // this.logs.push({
                    //   time: Date.now(), loginfo: "获取SN失败",
                    // });
                    // return;
                }
            });
        });
        this.ipcService.on("machineconfig", function (data) {
            _this._ngZone.run(function () {
                if (data.data.config !== undefined && data.data.config !== "") {
                    _this.configinfo.configid = data.data.config.StationID;
                    _this.configinfo.configname = data.data.config.StationNo;
                    _this.configinfo.version = data.data.config.version;
                    _this.configinfo.planCT = data.data.config.planCT;
                    _this.configinfo.line = data.data.config.line;
                    _this.asidecomponent.readmachineconfig(data.data.config);
                }
                if (data.data.pressInfo !== null && data.data.pressInfo !== "") {
                    _this.asidecomponent.readPressInfo(data.data.pressInfo);
                    _this.maxcheckinfo = data.data.pressInfo.checkAoffset > data.data.pressInfo.checkXoffset ? data.data.pressInfo.checkAoffset : data.data.pressInfo.checkXoffset;
                    _this.maxcheckinfo = _this.maxcheckinfo > data.data.pressInfo.checkYoffset ? _this.maxcheckinfo : data.data.pressInfo.checkYoffset;
                    _this.protimenumber = data.data.pressInfo.proTime;
                    _this.pressdata = data.data.pressInfo.pressdata;
                }
            });
        });
        // this.ipcService.on(MSG_TYPE.SEND_TO_MSG, (response) => {
        //   this._ngZone.run(() => {
        //     console.info(response.data);
        //     if (undefined !== response.data.operate) { //中间件发送来的日志
        //       //this.currenttime=Date.now();      
        //       this.logs.push({
        //         time: Date.now(), loginfo: response.data.operate
        //       });
        //       setTimeout(() => {
        //         document.getElementById('js_logDiv').scrollTop = document.getElementById('js_logDiv').scrollHeight;
        //       }, 0);
        //     }
        //     if (undefined !== response.data.error) {//中间件发送来的异常信息
        //       this.logs.push({
        //         time: Date.now(), loginfo: response.data.error
        //       });
        //       setTimeout(() => {
        //         document.getElementById('js_logDiv').scrollTop = document.getElementById('js_logDiv').scrollHeight;
        //       }, 0);
        //     }
        //   })
        // })
        window.onbeforeunload = function (event) {
            event.returnValue = false;
            //工作中或者复位中,不能关闭软件
            if (_this.machineStatus === 8 || _this.machineStatus === 4) {
                return;
            }
            // }else{
            //   this.ipcService.send("closewindow",{code:1});
            // }
            if (event.returnValue === "false" && _this.closewindow === true) {
                //event.returnValue = false;
                _this.showMessageBox(browserWindow, {
                    type: "warning",
                    message: "是否关闭软件",
                    buttons: ["确定", "取消"],
                    defaultId: 0,
                    cancelId: -1,
                }).then(function (btnIndex) {
                    if (btnIndex === 0) {
                        _this.ipcService.send("operate", { "code": 100 });
                        setTimeout(function () {
                            _this.ipcService.send("windowclose", {});
                        }, 5000);
                    }
                    else {
                        _this.closewindow = true;
                        event.returnValue = false;
                    }
                });
                _this.closewindow = false;
            }
        };
        this.ipcService.on("finishResult", function (data) {
            _this._ngZone.run(function () {
                // if(this.SNarray.indexOf(data.data.SN)===-1){
                //     this.SNarray.push(data.data.SN);
                // }
                _this.headerinfo.totalnumber++;
                if (data.data.code == 1) {
                    _this.headerinfo.goodnumber++;
                }
                else {
                    _this.headerinfo.badnumber++;
                }
                if (_this.ctboolean) {
                    _this.headerinfo.CT = (Date.now() - _this.AstartTime) / 1000;
                    _this.ctboolean = false;
                    _this.ctstarttime = Date.now();
                }
                else {
                    _this.headerinfo.CT = (Date.now() - _this.ctstarttime) / 1000; //CT计数  
                    _this.ctstarttime = Date.now();
                }
                _this.keycapsDetail.delplanProduct();
            });
        });
        this.ipcService.on("assembImage", function (data) {
            _this._ngZone.run(function () {
                setTimeout(function () {
                    _this.keycapsComponent.setImages(data.data.showimage);
                }, 3000);
            });
        });
        this.ipcService.on("machineclose", function (data) {
            _this._ngZone.run(function () {
                if (data.data.code === 0) {
                    _this.machineStatus = 1;
                    _this.keycapsDetail.changestatus(1);
                    _this.keycapsDetail.changenoconnect();
                    if (_this.closemsg) {
                        _this.showMessageBox(browserWindow, {
                            type: "warning",
                            message: "软件断开，请重启软件"
                        });
                    }
                    _this.closemsg = false;
                }
            });
        });
        this.ipcService.on("machineopen", function (data) {
            _this._ngZone.run(function () {
                if (data.data.code === 1) {
                    _this.ipcService.send("pageready", {});
                }
            });
        });
    };
    AppComponent.prototype.ngAfterViewInit = function () {
        this.ipcService.send("pageready", {});
        this.maskshow = false;
    };
    AppComponent.prototype.showIo = function (isioshow) {
        this.isShow = isioshow;
    };
    AppComponent.prototype.getplannum = function (plannum) {
        this.planproductnum = plannum;
    };
    AppComponent.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    AppComponent.prototype.getPressSN = function (SN) {
        this.pressSn = SN;
    };
    AppComponent.prototype.showconfig = function (configshow) {
        this.configShow = configshow;
        this.maskshow = configshow;
    };
    AppComponent.prototype.showfunlog = function (showlogfunction) {
        var _this = this;
        this.isUseShow = showlogfunction;
        this.maskshow = false;
        if (this.isUseShow == true) {
            this.logpanel.show()
                .then(function (result) {
                _this.logshow = result;
            });
        }
    };
    AppComponent.prototype.showlogpanel = function (logpanelshow) {
        this.logshow = logpanelshow;
        this.maskshow = true;
    };
    AppComponent.prototype.showpointpanel = function (Pointshow) {
        this.pointshow = Pointshow;
        this.maskshow = Pointshow;
    };
    AppComponent.prototype.showconfiginfo = function (stationname) {
        this.configinfo.configname = stationname[1];
        this.configinfo.configid = stationname[0];
        this.configinfo.version = stationname[2];
        this.configinfo.planCT = stationname[3];
        this.configinfo.line = stationname[4];
    };
    AppComponent.prototype.loginshow = function (logineeshow) {
        this.loginpanel.showLoginPanel();
        this.maskshow = false;
    };
    AppComponent.prototype.outlogin = function (result) {
        this.loginStatus.role = "";
        this.loginStatus.isLogin = false;
        this.loginshow(false);
    };
    AppComponent.prototype.getgoodnumber = function (goodnumber) {
        this.goodtotal = goodnumber[0];
        this.ctendtime = goodnumber[1];
    };
    AppComponent.prototype.getfailnumber = function (failnumber) {
        this.failtotal = failnumber;
    };
    AppComponent.prototype.getuserinfo = function (result) {
        this.asidecomponent.getuserRole(result.role);
        if (result.role == "admin") {
            this.loginStatus.role = "管理员";
        }
        else {
            this.loginStatus.role = "操作员";
        }
        this.loginStatus.isLogin = result.isLogin;
        this.maskshow = true;
    };
    AppComponent.prototype.showProTime = function (protime) {
        this.protimenumber = protime[0];
        this.pressdata = protime[1];
        this.maxcheckinfo = protime[2];
        for (var i = 0; i < 50; i++) {
            this.press.push(this.pressdata);
        }
        this.keycapsComponent.updateLine(this.maxcheckinfo, this.press, 2);
        this.press = [];
    };
    AppComponent.prototype.changingpwd = function (result) {
        this.loginpanel.showLoginPanel();
        this.loginpanel.changpwd();
        this.maskshow = false;
    };
    // getSNtotal(sntotal:string[]){
    //   this.SNarray=sntotal;
    // }
    AppComponent.prototype.closechangepwd = function (result) {
        this.maskshow = result;
    };
    __decorate([
        core_1.ViewChild(centerInfo_1.LeftInfoComponent),
        __metadata("design:type", centerInfo_1.LeftInfoComponent)
    ], AppComponent.prototype, "keycapsComponent", void 0);
    __decorate([
        core_1.ViewChild(footerInfo_1.footerInfoComponent),
        __metadata("design:type", footerInfo_1.footerInfoComponent)
    ], AppComponent.prototype, "keycapsDetail", void 0);
    __decorate([
        core_1.ViewChild(headerinfo_2.HeaderinfoComponent),
        __metadata("design:type", headerinfo_2.HeaderinfoComponent)
    ], AppComponent.prototype, "headerinfomation", void 0);
    __decorate([
        core_1.ViewChild(login_panel_1.LoginlPanel),
        __metadata("design:type", login_panel_1.LoginlPanel)
    ], AppComponent.prototype, "loginpanel", void 0);
    __decorate([
        core_1.ViewChild(logPanel_1.LogPanel),
        __metadata("design:type", logPanel_1.LogPanel)
    ], AppComponent.prototype, "logpanel", void 0);
    __decorate([
        core_1.ViewChild(aside_1.AsideComponent),
        __metadata("design:type", aside_1.AsideComponent)
    ], AppComponent.prototype, "asidecomponent", void 0);
    AppComponent = __decorate([
        core_1.Component({
            selector: 'root',
            templateUrl: "./webApp/component/root/root.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone,
            ipc_service_1.IPCService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=root.js.map