"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var ECharts = require("echarts");
var KeycapsComponent = /** @class */ (function () {
    // Make gradient line here
    function KeycapsComponent(_ngZone, ipcService, elementRef) {
        var _this = this;
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.ipcService = ipcService;
        this.elementRef = elementRef;
        this.valueList = [];
        this.dateList = [];
        this.ipcService.on("TensionInfo", function (data) {
            if (_this.protime > 1000) {
                _this.protime = _this.protime / 1000;
                for (var i = 0; i < _this.protime; i++) {
                    _this.dateList.push(i);
                }
            }
            _this._ngZone.run(function () {
                _this.valueList.push(data.data.data);
                _this.initLanguageChart();
            });
        });
        this.option = {
            //Make gradient line here
            visualMap: [{
                    show: false,
                    type: 'continuous',
                    seriesIndex: 0,
                    min: 0,
                    max: 150
                }, {
                    show: false,
                    type: 'continuous',
                    seriesIndex: 1,
                    dimension: 0,
                    min: 0,
                    max: this.dateList.length - 1
                }],
            title: [{
                    left: 'center',
                    text: '压力折线图'
                }, {}],
            tooltip: {
                trigger: 'axis'
            },
            xAxis: [{
                    data: this.dateList
                }, {}],
            yAxis: [{
                    splitLine: { show: false }
                }, {}],
            grid: [{
                    bottom: '10%'
                }, {
                    top: '10%'
                }],
            series: [{
                    type: 'line',
                    showSymbol: false,
                    data: this.valueList
                }, {
                    type: 'line',
                    showSymbol: false,
                    data: this.valueList,
                    // xAxisIndex: 1,
                    yAxisIndex: 1
                }]
        };
    }
    KeycapsComponent.prototype.ngAfterViewInit = function () {
        this.initLanguageChart();
    };
    KeycapsComponent.prototype.initLanguageChart = function () {
        var div = this.elementRef.nativeElement.querySelector(".keycaps-det");
        this.chart = ECharts.init(div);
        // console.info(this.pressure.length)
        this.chart.setOption(this.option);
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], KeycapsComponent.prototype, "protime", void 0);
    KeycapsComponent = __decorate([
        core_1.Component({
            selector: 'keycaps',
            templateUrl: "./webApp/component/keycaps/keycaps.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService, core_1.ElementRef])
    ], KeycapsComponent);
    return KeycapsComponent;
}());
exports.KeycapsComponent = KeycapsComponent;
//# sourceMappingURL=keycaps.js.map