"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var assembling_1 = require("../../common/bean/assembling");
var ipc_service_1 = require("../../common/service/ipc.service");
var headerinfo_1 = require("../../common/bean/headerinfo");
var dialog = nodeRequire('electron').remote.dialog;
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var footerInfoComponent = /** @class */ (function () {
    function footerInfoComponent(_ngZone, ipcService) {
        var _this = this;
        this.getplanProduct = new core_1.EventEmitter();
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.status = "未初始化";
        this.ipcService = ipcService;
        this.machineStatus = 7;
        this.letpressclass = [false, false];
        this.planProductNum = 100;
        this.SFCmessage = "";
        this.searchSN = "";
        this.SNsearch = [false, false, false];
        this.workmodels = {
            scanSN: 1,
            passStation: 1,
            IsPress: 1,
            putSMT: 1,
        };
        this.workmodel = {
            passStation: false,
            scanSN: false,
            IsPress: false,
            putSMT: false,
        };
        this.communciateStatus = {
            emengencyclass: false,
            safedoorclass: false,
            gunclass: false,
            pressclass: false,
            ccdclass: false,
            sfcclass: false,
        };
        this.ipcService.on("SFCmessage", function (data) {
            _this._ngZone.run(function () {
                _this.SFCmessage = data.data.message;
            });
        });
        this.ipcService.on("communicateStatus", function (data) {
            _this._ngZone.run(function () {
                if (data.data.code === 0) {
                    _this.communciateStatus.emengencyclass = true;
                }
                else if (data.data.code === 1) {
                    if (data.data.data === 1) {
                        _this.communciateStatus.safedoorclass = true;
                    }
                    else {
                        _this.communciateStatus.safedoorclass = false;
                    }
                }
                else if (data.data.code === 2) {
                    if (data.data.data === 1 && _this.communciateStatus.gunclass === false) {
                        _this.communciateStatus.gunclass = true;
                    }
                    else if (data.data.data === 0 && _this.communciateStatus.gunclass === true) {
                        _this.communciateStatus.gunclass = false;
                    }
                }
                else if (data.data.code === 3) {
                    if (data.data.data === 1) {
                        _this.communciateStatus.pressclass = true;
                    }
                    else {
                        _this.communciateStatus.pressclass = false;
                    }
                }
                else if (data.data.code === 4) {
                    if (data.data.data === 1) {
                        _this.communciateStatus.ccdclass = true;
                    }
                    else {
                        _this.communciateStatus.ccdclass = false;
                    }
                }
                else if (data.data.code === 5) {
                    if (data.data.data === 1) {
                        _this.communciateStatus.sfcclass = true;
                    }
                    else {
                        _this.communciateStatus.sfcclass = false;
                    }
                }
            });
        });
    }
    footerInfoComponent.prototype.changenoconnect = function () {
        this.communciateStatus = {
            emengencyclass: false,
            safedoorclass: false,
            gunclass: false,
            pressclass: false,
            ccdclass: false,
            sfcclass: false,
        };
    };
    footerInfoComponent.prototype.searchSNinfo = function () {
        this.SNsearch = [true, false, false];
        if (this.searchSN.length === undefined) {
            return;
        }
        if (this.searchSN.length < 10) {
            this.showMessageBox(browserWindow, {
                type: "warning",
                message: "条码读取错误，请重新输入",
            });
            return;
        }
        else {
            this.ipcService.send("CheckSN", { "type": 0, "SN": this.searchSN, }); //查询SFC
            this.SFCmessage = "";
        }
    };
    footerInfoComponent.prototype.putSMT = function () {
        this.SNsearch = [false, true, false];
        if (this.searchSN === undefined) {
            return;
        }
        if (this.searchSN.length < 10) {
            this.showMessageBox(browserWindow, {
                type: "warning",
                message: "条码读取错误，请重新输入",
            });
            return;
        }
        else {
            this.ipcService.send("CheckSN", { "type": 1, "SN": this.searchSN, }); //上传SMT
            this.SFCmessage = "";
        }
    };
    footerInfoComponent.prototype.putSFC = function () {
        this.SNsearch = [false, false, true];
        if (this.searchSN.length === undefined) {
            return;
        }
        if (this.searchSN.length < 10) {
            this.showMessageBox(browserWindow, {
                type: "warning",
                message: "条码读取错误，请重新输入",
            });
            return;
        }
        else {
            this.ipcService.send("CheckSN", { "type": 2, "SN": this.searchSN }); //上传sfc
            this.SFCmessage = "";
        }
    };
    footerInfoComponent.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    footerInfoComponent.prototype.cleardata = function () {
        this.headerinfo.goodnumber = 0;
        this.headerinfo.badnumber = 0;
        this.headerinfo.totalnumber = 0;
        this.ipcService.send("clearproduct", {});
    };
    footerInfoComponent.prototype.ngOnInit = function () {
        this.getplanProduct.emit(this.planProductNum);
    };
    footerInfoComponent.prototype.getPlanNum = function (num) {
        if (this.planProductNum < 0) {
            this.planProductNum = 0;
            return;
        }
        this.getplanProduct.emit(this.planProductNum);
    };
    footerInfoComponent.prototype.delplanProduct = function () {
        this.planProductNum--;
        if (this.planProductNum < 0) {
            this.planProductNum = 0;
            return;
        }
        this.ipcService.send("sendPlanProduct", { "planProduct": this.planProductNum });
        this.getplanProduct.emit(this.planProductNum);
    };
    footerInfoComponent.prototype.changestatus = function (data) {
        this.machineStatus = data;
        switch (data) {
            case 0:
                this.status = "未初始化"; //red
                break;
            case 1:
                this.status = "未连接"; //red
                break;
            case 2:
                this.status = "急停"; //red
                break;
            case 3:
                this.status = "请复位"; //red
                break;
            case 4:
                this.status = "复位中"; //green
                break;
            case 5:
                this.status = "停止中"; //red
                break;
            case 6:
                this.status = "就绪"; //blue
                break;
            case 7:
                this.status = "暂停"; //yellow
                break;
            case 8:
                this.status = "工作中"; //green
                break;
        }
    };
    footerInfoComponent.prototype.changedata = function (type) {
        if (this.workmodel.scanSN === true) {
            this.workmodels.scanSN = 0;
        }
        else {
            this.workmodels.scanSN = 1;
        }
        if (this.workmodel.passStation === true) {
            this.workmodels.passStation = 0;
        }
        else {
            this.workmodels.passStation = 1;
        }
        if (this.workmodel.IsPress === true) {
            this.workmodels.IsPress = 0;
        }
        else {
            this.workmodels.IsPress = 1;
        }
        if (this.workmodel.putSMT === true) {
            this.workmodels.putSMT = 0;
        }
        else {
            this.workmodels.putSMT = 1;
        }
        this.ipcService.send("workway", this.workmodels);
    };
    footerInfoComponent.prototype.letspress = function (type) {
        if (type === 5) {
            this.letpressclass = [true, false];
        }
        else if (type === 6) {
            this.letpressclass = [false, true];
        }
        if (this.machineStatus === 6) {
            this.ipcService.send("operate", {
                "code": type
            });
        }
        else {
            this.showMessageBox(browserWindow, {
                type: "warning",
                message: "不是在就绪状态下，不可操作",
            });
            return;
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", assembling_1.Assembling)
    ], footerInfoComponent.prototype, "assembling", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], footerInfoComponent.prototype, "configinfos", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", String)
    ], footerInfoComponent.prototype, "pressSn", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", headerinfo_1.Headerinfo)
    ], footerInfoComponent.prototype, "headerinfo", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], footerInfoComponent.prototype, "getplanProduct", void 0);
    footerInfoComponent = __decorate([
        core_1.Component({
            selector: 'footerinfo',
            templateUrl: "./webApp/component/footerInfo/footerInfo.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], footerInfoComponent);
    return footerInfoComponent;
}());
exports.footerInfoComponent = footerInfoComponent;
//# sourceMappingURL=footerInfo.js.map