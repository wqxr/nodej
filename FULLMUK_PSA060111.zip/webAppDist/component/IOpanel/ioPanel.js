"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var IOData_1 = require("../../common/bean/IOData");
var ipc_service_1 = require("../../common/service/ipc.service");
var IOpanelComponemt = /** @class */ (function () {
    function IOpanelComponemt(_ngZone, ipcService) {
        this.isShow = true;
        this.iOList = IOData_1.IOList;
        this.ioisShow = new core_1.EventEmitter();
        this.iscongigshow = true;
        this._ngZone = _ngZone;
        this.ipcService = ipcService;
        this.iOList[0].hidden = false;
        this.ioCards = [];
        for (var j = 0; j < 4; j++) {
            this.ioCards[j] = [];
            for (var i = 0; i < 18; i++) {
                this.ioCards[j][i] = new CardIO();
            }
        }
    }
    IOpanelComponemt.prototype.ngOnInit = function () {
        var _this = this;
        this.ipcService.on("IoStatus", function (message) {
            _this._ngZone.run(function () {
                var ioValue = message.data.data.toString(2);
                var cardId = message.data.cardID;
                while (ioValue.length < 16) {
                    ioValue = "0" + ioValue;
                }
                ;
                for (var i = 0; i < ioValue.length; i++) {
                    _this.ioCards[cardId - 1][i].input = ioValue.charAt(ioValue.length - i - 1);
                }
                // console.info(this.ioCards);
                //this.ioCards[cardId-1][ioValue].input = ioValue;
            });
        });
    };
    IOpanelComponemt.prototype.onclose = function () {
        this.ioisShow.emit(this.isShow);
    };
    IOpanelComponemt.prototype.operateIo = function (io) {
        // let val = io.value;
        io.value = io.value === 0 ? 1 : 0;
        // let value=val;
        var name = io.name;
        this.ipcService.send("operateIo", {
            'cardId': io.cardId, 'index': io.index, 'value': io.value, 'name': name
        });
        // if(io.value===1){
        //     io.value=0;
        // }else{
        //     io.value=1;
        // }
    };
    IOpanelComponemt.prototype.switchIoOff = function (type, name) {
        this.ipcService.send("operateIo", {
            cardId: type,
            Ioname: name,
            value: 0
        });
    };
    IOpanelComponemt.prototype.switchTab = function (tabIndex) {
        this.iOList.forEach(function (item) {
            item.hidden = true;
        });
        this.iOList[tabIndex].hidden = false;
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], IOpanelComponemt.prototype, "ioisShow", void 0);
    IOpanelComponemt = __decorate([
        core_1.Component({
            selector: 'io-panel',
            templateUrl: "./webApp/component/IOpanel/ioPanel.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], IOpanelComponemt);
    return IOpanelComponemt;
}());
exports.IOpanelComponemt = IOpanelComponemt;
var CardIO = /** @class */ (function () {
    function CardIO() {
    }
    return CardIO;
}());
//# sourceMappingURL=ioPanel.js.map