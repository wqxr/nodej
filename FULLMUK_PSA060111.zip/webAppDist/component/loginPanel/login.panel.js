"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var LoginlPanel = /** @class */ (function () {
    function LoginlPanel(ipcService) {
        this.changepwd = false;
        this.loginResult = new core_1.EventEmitter();
        this.closeResult = new core_1.EventEmitter();
        this.display = "block";
        this.username = "";
        this.password = "";
        this.newpassword = "";
        this.ipcService = ipcService;
        this.changeresult = false;
        this.role = "";
    }
    LoginlPanel.prototype.ngOnInit = function () {
        var _this = this;
        this.ipcService.on("loginresult", function (response) {
            if (response.data.resultCode !== 1) {
                _this.errorMsg = "您输入的密码错误";
                _this.password = "";
                return;
            }
            if (response.data.resultCode === 1) {
                _this.loginResult.emit({
                    isLogin: true, role: _this.username,
                });
                _this.hiddenLoginPanel();
                _this.password = "";
            }
        });
        this.ipcService.on("modifypwdresult", function (response) {
            if (response.data.resultCode === 0) {
            }
            else {
                _this.changepwd = false;
                _this.changeresult = true;
                _this.errorMsg = "修改密码成功，请重新登录";
                _this.password = "";
            }
        });
    };
    LoginlPanel.prototype.close = function () {
        this.closeResult.emit(true);
        this.hiddenLoginPanel();
    };
    LoginlPanel.prototype.userlogin = function () {
        this.changepwd = false;
        if (false === this.check()) {
            return;
        }
        if (!isNaN(this.role)) {
            this.username = "op";
        }
        else {
            this.username = "admin";
        }
        // if( this.role === "admin"){
        //   this.username = "admin";
        // }else{
        //   this.username = "1";
        // }
        this.ipcService.send("UserLogin", { "username": this.role, "psw": this.password, "code": 1 }); //1代表登录
        //  this.display="none";
        //   this.loginResult.emit({
        //     isLogin: true, role: this.role,
        //   });
    };
    LoginlPanel.prototype.loginin = function (event) {
        if (event.keyCode === 13) {
            this.userlogin();
        }
    };
    LoginlPanel.prototype.changpwd = function () {
        this.changepwd = true;
        this.newpassword = "";
        this.oldpassword = "";
    };
    LoginlPanel.prototype.hiddenLoginPanel = function () {
        this.display = "none";
    };
    LoginlPanel.prototype.showLoginPanel = function () {
        this.changepwd = false;
        this.display = "block";
        this.password = "";
    };
    LoginlPanel.prototype.check = function () {
        this.errorMsg = "";
        if (!this.password || !this.role) {
            this.errorMsg = "请输入用户名或者密码";
            return false;
        }
        return true;
    };
    LoginlPanel.prototype.updatepwd = function () {
        if (this.oldpassword !== this.newpassword) {
            this.errorMsg = "密码不相同，请确认";
            return;
        }
        else {
            this.ipcService.send("changepwd", { "role": this.role, "newpassword": this.newpassword, "oldpassword": this.password });
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], LoginlPanel.prototype, "loginStatus", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], LoginlPanel.prototype, "onlogin", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], LoginlPanel.prototype, "loginResult", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], LoginlPanel.prototype, "closeResult", void 0);
    LoginlPanel = __decorate([
        core_1.Component({
            selector: 'login-panel',
            templateUrl: "./webApp/component/loginPanel/loginPanel.html",
        }),
        __metadata("design:paramtypes", [ipc_service_1.IPCService])
    ], LoginlPanel);
    return LoginlPanel;
}());
exports.LoginlPanel = LoginlPanel;
//# sourceMappingURL=login.panel.js.map