"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var ChangePassword = /** @class */ (function () {
    // @Output()
    // private loginResult = new EventEmitter<{ isLogin: boolean, role: string }>();
    function ChangePassword(ipcService) {
        this.display = "none";
        this.oldPsw = "";
        this.passwordAgain = "";
        this.password = "";
        this.ipcService = ipcService;
        this.errorMsg = "";
    }
    ChangePassword.prototype.ngOnInit = function () {
        // this.ipcService.on(MSG_TYPE.SEND_CMD_RESULT, (response) => {
        //   if (response.data.cmd !== CMD.LOGIN) {
        //     return;
        //   }
        //   if (response.data.resultCode === 1) {
        //     this.loginResult.emit({
        //       isLogin: true, role: "admin"
        //     });
        //     this.hidden();
        //     this.resolveFunc();
        //   }
        // });
    };
    ChangePassword.prototype.reset = function () {
        console.log(this.oldPsw, this.password, this.passwordAgain);
        if (false === this.check()) {
            return;
        }
        this.ipcService.send("changepwd", { "oldPsw": this.oldPsw, "newPsw": this.password });
        this.hidden();
    };
    ChangePassword.prototype.show = function () {
        var _this = this;
        this.display = "flex";
        return new Promise(function (resolve, reject) {
            _this.resolveFunc = resolve;
            _this.rejectFunc = reject;
        });
    };
    ChangePassword.prototype.hidden = function () {
        this.display = "none";
    };
    ChangePassword.prototype.check = function () {
        this.errorMsg = "";
        if (!this.oldPsw) {
            this.errorMsg = "请输入旧密码";
            return false;
        }
        if (!this.password) {
            this.errorMsg = "请输入新密码";
            return false;
        }
        if (!this.passwordAgain) {
            this.errorMsg = "请再次输入新密码";
            return false;
        }
        if (this.password !== this.passwordAgain) {
            this.errorMsg = "两次输入的密码不一致";
            return false;
        }
        return true;
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], ChangePassword.prototype, "userinformation", void 0);
    ChangePassword = __decorate([
        core_1.Component({
            selector: 'change-password',
            templateUrl: "./webApp/component/changePassword/changePassword.html",
        }),
        __metadata("design:paramtypes", [ipc_service_1.IPCService])
    ], ChangePassword);
    return ChangePassword;
}());
exports.ChangePassword = ChangePassword;
//# sourceMappingURL=change.password.js.map