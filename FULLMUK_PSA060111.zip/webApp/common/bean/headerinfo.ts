export class Headerinfo {
    CT: number;//ct时间
    goodnumber: number = 1;//良数
    badnumber: number = 0;//不良数
    goodprobability: number;//良率
    totalnumber: number = 2;//总数
    Acycletime: number;//贴合时间
    newSN: string;
    oldSN: string;
   
}