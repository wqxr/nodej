"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var root_1 = require("./component/root/root");
var headerinfo_1 = require("./component/headerinfo/headerinfo");
var forms_1 = require("@angular/forms");
var centerInfo_1 = require("./component/centerInfo/centerInfo");
var aside_1 = require("./component/aside/aside");
var logPanel_1 = require("./component/logPanel/logPanel");
var pointPanel_1 = require("./component/pointPanel/pointPanel");
var login_panel_1 = require("./component/loginPanel/login.panel");
var stationB_1 = require("./component/stationB/stationB");
var stationA_1 = require("./component/stationA/stationA");
var savepoint_1 = require("./component/savepoint/savepoint");
var ioPanel_1 = require("./component/IOpanel/ioPanel");
var footerInfo_1 = require("./component/footerInfo/footerInfo");
var ipc_service_1 = require("./common/service/ipc.service");
//import { AssemblingService } from './service/assemblingService';
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [
                platform_browser_1.BrowserModule,
                forms_1.FormsModule,
            ],
            declarations: [
                root_1.AppComponent,
                headerinfo_1.HeaderinfoComponent,
                centerInfo_1.LeftInfoComponent,
                footerInfo_1.footerInfoComponent,
                aside_1.AsideComponent,
                logPanel_1.LogPanel,
                pointPanel_1.PointPanel,
                stationB_1.StationB,
                stationA_1.StationA,
                login_panel_1.LoginlPanel,
                ioPanel_1.IOpanelComponemt,
                savepoint_1.SavePointComponent
            ],
            providers: [
                ipc_service_1.IPCService,
            ],
            bootstrap: [root_1.AppComponent]
        })
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map