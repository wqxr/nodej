"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var dialog = nodeRequire('electron').remote.dialog;
var fs = nodeRequire('fs');
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var SavePointComponent = /** @class */ (function () {
    function SavePointComponent(_ngZone, ipcService) {
        var _this = this;
        this.isShow = true;
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.getpointInfo = [];
        this.matchPoint = [];
        this.ipcService = ipcService;
        this.machinestatus = 0;
        for (var j = 0; j < 7; j++) {
            this.getpointInfo[j] = [];
            this.matchPoint[j] = [];
            for (var i = 0; i < 13; i++) {
                this.getpointInfo[j][i] = new getPointdata();
                this.matchPoint[j][i] = new getPointdata();
            }
        }
        this.ipcService.on("setPointResult", function (data) {
            _this._ngZone.run(function () {
                if (data.data.code === 1) {
                    _this.showMessageBox(browserWindow, {
                        type: "warning",
                        message: "保存成功"
                    });
                }
                else {
                    _this.showMessageBox(browserWindow, {
                        type: "warning",
                        message: "保存失败"
                    });
                }
            });
        });
    }
    SavePointComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.ipcService.on("getPoint", function (data) {
            _this._ngZone.run(function () {
                _this.getPointfun(data.data.station, data.data.xPoint, data.data.yPoint, data.data.zPoint, data.data.index, data.data.uPoint);
            });
        });
    };
    SavePointComponent.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    SavePointComponent.prototype.getPointfun = function (station, xPoint, yPoint, zPoint, index, uPoint) {
        this.getpointInfo[station][index].Xpoint = parseFloat(xPoint.toFixed(3));
        this.getpointInfo[station][index].Ypoint = parseFloat(yPoint.toFixed(3));
        this.getpointInfo[station][index].Zpoint = parseFloat(zPoint.toFixed(3));
        this.getpointInfo[station][index].Upoint = parseFloat(uPoint.toFixed(3));
        this.matchPoint[station][index].Xpoint = parseFloat(xPoint.toFixed(3));
        this.matchPoint[station][index].Ypoint = parseFloat(yPoint.toFixed(3));
        this.matchPoint[station][index].Zpoint = parseFloat(zPoint.toFixed(3));
        this.matchPoint[station][index].Upoint = parseFloat(uPoint.toFixed(3));
    };
    SavePointComponent.prototype.getstatus = function (data) {
        this.machinestatus = data;
    };
    SavePointComponent.prototype.getuserrole = function (role) {
        this.userrole = role;
    };
    SavePointComponent.prototype.savepoint = function () {
        var _this = this;
        this.showMessageBox(browserWindow, {
            type: "warning",
            message: "是否保存",
            buttons: ["确定", "取消"],
            defaultId: 0,
            cancelId: -1,
        }).then(function (btnIndex) {
            if (btnIndex === 0) {
                var _loop_1 = function (i) {
                    var _loop_2 = function (j) {
                        if (_this.getpointInfo[i][j].Xpoint !== _this.matchPoint[i][j].Xpoint) {
                            setTimeout(function () {
                                _this.ipcService.send("setPoint", { "station": i, "index": j, "xPoint": _this.getpointInfo[i][j].Xpoint, "yPoint": _this.getpointInfo[i][j].Ypoint, "zPoint": _this.getpointInfo[i][j].Zpoint, "uPoint": _this.getpointInfo[i][j].Upoint, "prexpoint": _this.matchPoint[i][j].Xpoint, "change": "x" });
                                _this.matchPoint[i][j].Xpoint = _this.getpointInfo[i][j].Xpoint;
                            }, 100);
                        }
                        if (_this.getpointInfo[i][j].Ypoint !== _this.matchPoint[i][j].Ypoint) {
                            setTimeout(function () {
                                _this.ipcService.send("setPoint", { "station": i, "index": j, "xPoint": _this.getpointInfo[i][j].Xpoint, "yPoint": _this.getpointInfo[i][j].Ypoint, "zPoint": _this.getpointInfo[i][j].Zpoint, "uPoint": _this.getpointInfo[i][j].Upoint, "preypoint": _this.matchPoint[i][j].Ypoint, "change": "y" });
                                _this.matchPoint[i][j].Ypoint = _this.getpointInfo[i][j].Ypoint;
                            }, 100);
                        }
                        if (_this.getpointInfo[i][j].Zpoint !== _this.matchPoint[i][j].Zpoint) {
                            setTimeout(function () {
                                _this.ipcService.send("setPoint", { "station": i, "index": j, "xPoint": _this.getpointInfo[i][j].Xpoint, "yPoint": _this.getpointInfo[i][j].Ypoint, "zPoint": _this.getpointInfo[i][j].Zpoint, "uPoint": _this.getpointInfo[i][j].Upoint, "prezpoint": _this.matchPoint[i][j].Zpoint, "change": "z" });
                                _this.matchPoint[i][j].Zpoint = _this.getpointInfo[i][j].Zpoint;
                            }, 100);
                        }
                        if (_this.getpointInfo[i][j].Upoint !== _this.matchPoint[i][j].Upoint) {
                            setTimeout(function () {
                                _this.ipcService.send("setPoint", { "station": i, "index": j, "xPoint": _this.getpointInfo[i][j].Xpoint, "yPoint": _this.getpointInfo[i][j].Ypoint, "zPoint": _this.getpointInfo[i][j].Zpoint, "uPoint": _this.getpointInfo[i][j].Upoint, "preupoint": _this.matchPoint[i][j].Upoint, "change": "u" });
                                _this.matchPoint[i][j].Upoint = _this.getpointInfo[i][j].Upoint;
                            }, 100);
                        }
                    };
                    for (var j = 0; j < _this.getpointInfo[i].length; j++) {
                        _loop_2(j);
                    }
                };
                for (var i = 0; i < _this.getpointInfo.length; i++) {
                    _loop_1(i);
                }
            }
            else {
                _this.getpointInfo = _this.matchPoint;
            }
        });
    };
    SavePointComponent = __decorate([
        core_1.Component({
            selector: 'savepoint',
            templateUrl: "./webApp/component/savepoint/savepoint.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], SavePointComponent);
    return SavePointComponent;
}());
exports.SavePointComponent = SavePointComponent;
var getPointdata = /** @class */ (function () {
    function getPointdata() {
        this.station = 0;
        this.index = 0;
        this.Xpoint = 0;
        this.Ypoint = 0;
        this.Zpoint = 0;
        this.Upoint = 0;
        this.total = 0;
    }
    return getPointdata;
}());
//# sourceMappingURL=savepoint.js.map