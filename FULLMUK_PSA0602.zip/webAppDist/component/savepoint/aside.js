"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var stationA_1 = require("../stationA/stationA");
var stationB_1 = require("../stationB/stationB");
var AsideComponent = /** @class */ (function () {
    function AsideComponent(_ngZone, ipcService) {
        this.pointshow = true;
        this.stationAshow = false;
        this.stationBshow = true;
        this.openIOshow = true;
        this.configShow = true;
        this.openteacherPoint = true;
        this.configinfo = {
            configname: "",
            configid: "",
        };
        this.configisShow = new core_1.EventEmitter();
        this.configinfos = new core_1.EventEmitter();
        this.sendProtime = new core_1.EventEmitter();
        this.iscongigshow = true;
        this.SAVE_PATH = "D:/ShopFlow/assemble.ini";
        this.startclass = false;
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.showFlag = [true, false, false, false];
        //  console.log(_.isString(this.title));
        this.config = {
            Ip: "",
            Station: "",
            StationID: "",
            StationNo: "",
            MAC_ADDR: "",
            line: "",
        };
        this.ipcService = ipcService;
    }
    AsideComponent.prototype.showconfiginfo = function (stationname) {
        this.configinfo.configname = stationname[1];
        this.configinfo.configid = stationname[0];
        this.configShow = true;
        this.configinfos.emit([this.config.StationID, this.config.StationNo]);
    };
    AsideComponent.prototype.showProTime = function (protime) {
        this.protimenumber = protime[0];
        //this.pressdata=protime[1];
        this.sendProtime.emit(protime);
    };
    AsideComponent.prototype.onclose = function () {
        this.configisShow.emit(this.iscongigshow);
        this.iscongigshow = !this.iscongigshow;
    };
    AsideComponent.prototype.openStationA = function () {
        this.stationAshow = false;
        this.stationBshow = true;
        this.showFlag = [true, false, false, false];
        this.openIOshow = true;
        this.openteacherPoint = true;
    };
    AsideComponent.prototype.openstationB = function () {
        this.stationBshow = false;
        this.stationAshow = true;
        this.openIOshow = true;
        this.showFlag = [false, true, false, false];
        this.openteacherPoint = true;
    };
    AsideComponent.prototype.openIOpanel = function () {
        this.stationAshow = true;
        this.stationBshow = true;
        this.openIOshow = false;
        this.openteacherPoint = true;
        this.showFlag = [false, false, true, false];
    };
    AsideComponent.prototype.openTeacher = function () {
        this.stationAshow = true;
        this.stationBshow = true;
        this.openIOshow = true;
        this.openteacherPoint = false;
        this.showFlag = [false, false, false, true];
    };
    AsideComponent.prototype.readmachineconfig = function (data) {
        this.config = data;
        this.stationA.readmachineconfigs(this.config);
    };
    AsideComponent.prototype.readPressInfo = function (data) {
        // window.setTimeout(()=>{
        this.stationB.readconfigs(data);
        //},1000)
        //this.stationB.readconfigs(data);
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], AsideComponent.prototype, "configisShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], AsideComponent.prototype, "configinfos", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], AsideComponent.prototype, "sendProtime", void 0);
    __decorate([
        core_1.ViewChild(stationA_1.StationA),
        __metadata("design:type", stationA_1.StationA)
    ], AsideComponent.prototype, "stationA", void 0);
    __decorate([
        core_1.ViewChild(stationB_1.StationB),
        __metadata("design:type", stationB_1.StationB)
    ], AsideComponent.prototype, "stationB", void 0);
    AsideComponent = __decorate([
        core_1.Component({
            selector: 'config-panel',
            templateUrl: "./webApp/component/aside/aside.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], AsideComponent);
    return AsideComponent;
}());
exports.AsideComponent = AsideComponent;
//# sourceMappingURL=aside.js.map