"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var headerinfo_1 = require("../../common/bean/headerinfo");
var ipc_service_1 = require("../../common/service/ipc.service");
var dialog = nodeRequire('electron').remote.dialog;
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var HeaderinfoComponent = /** @class */ (function () {
    function HeaderinfoComponent(_ngZone, ipcService) {
        var _this = this;
        this.isShow = false;
        this.iscongigshow = false;
        this.configshowtext = "配置面板";
        this.ioisshowText = "IO面板";
        this.isrepaire = false;
        this.ismatain = false;
        this.isUseShow = false;
        this.pointShow = false;
        this.openlogclass = false; //日志面板样式
        this.setconfigclass = false; //配置面板样式
        this.fullScreenFlag = false; //全屏
        this.ioisShow = new core_1.EventEmitter();
        this.configisShow = new core_1.EventEmitter();
        this.isUseShowfun = new core_1.EventEmitter();
        this.ispointPanelShow = new core_1.EventEmitter();
        this.isloginPanelShow = new core_1.EventEmitter();
        this.ischangepwdPanelShow = new core_1.EventEmitter();
        this.changepassword = new core_1.EventEmitter();
        this.outlogin = new core_1.EventEmitter();
        this.runmodel = new core_1.EventEmitter();
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.ipcService = ipcService;
        this.styleclass = [false, false, false, false, false, false, false, false];
        this.chosematerial = "出料";
        this.status = "请复位";
        this.chosewarehouse = "清除料仓";
        // this.opreatelist=[];
        this.showloginout = true;
        this.loginstatus = "退出登录";
        this.machineStatus = 0;
        this.productclass = [false, true];
        this.productimodel = true;
        this.runstyle = false;
        this.issuspend = true;
        this.repairtime = "维修";
        this.protecttime = "保养";
        this.repairtotaltime = 0;
        this.mataintotaltime = 0;
        this.repairAlltime = 0;
        this.matainAlltime = 0;
        this.repairstartTime = 0;
        this.matainstarttime = 0;
        this.matainendtime = 0;
        this.machineTime = {
            "product": "",
            "cm": "WISTRON",
            "cm_line": "",
            "machine_number": "",
            "manufacturer": "FP",
            "time_local": "",
            "total_time": "3600",
            "scheduled_time": "3600",
            "unscheduled_downtime": "",
            "scheduled_downtime": "",
            "engineering_time": "",
            "idle_time": "",
            "production_time": "",
            "unit_count": 0,
            "pass_count": 0,
            "pass_cycle_time": "",
            "fail_cycle_time": "",
            "planned_cycle_time": "",
            "Date": "",
            "Hour": "",
        };
        this.ipcService.on("machineTime", function (response) {
            _this._ngZone.run(function () {
                var now = new Date();
                if (_this.isrepaire === true) {
                    _this.repairAlltime = _this.repairtotaltime + (Date.now() - _this.repairstartTime) / 1000;
                }
                else if (_this.ismatain === true) {
                    _this.matainAlltime = _this.mataintotaltime + (Date.now() - _this.matainstarttime) / 1000;
                }
                // this.repairtotaltime= this.repairtotaltime+(Date.now()-this.repairstartTime)/1000;
                // this.mataintotaltime=this.mataintotaltime+(Date.now()-this.matainstarttime)/1000;
                _this.machineTime = response.data;
                _this.machineTime.cm = "WISTRON";
                _this.machineTime.manufacturer = "FP";
                _this.machineTime.planned_cycle_time = _this.configinfomation.planCT;
                _this.machineTime.cm_line = _this.configinfomation.line;
                _this.machineTime.machine_number = _this.configinfomation.configid;
                _this.machineTime.scheduled_downtime = "" + _this.repairAlltime.toFixed(1);
                _this.machineTime.engineering_time = "" + _this.matainAlltime.toFixed(1);
                //  this.machineTime.pass_cycle_time=response.data.pass_cycle_time.toFixed(1);
                _this.machineTime.total_time = "3600";
                _this.machineTime.scheduled_time = "3600";
                //this.machineTime.time_local = "" + now.getHours() + ":00:00";
                //this.machineTime.time_local=response.data.time_local;
                // if(now.getHours()===0){
                //   this.ipcService.send("newFile",{});
                // }
                _this.machineTime.idle_time = ((3600 - _this.repairAlltime - _this.matainAlltime - response.data.production_time).toFixed(1)).toString();
                // this.machineTime.Date = "" + now.getFullYear()  + (now.getMonth() + 1)  + now.getDate();
                //this.machineTime.Hour = "" + now.getHours();
                //console.info("fdsadf"+this.repairtotaltime)
                _this.ipcService.send("machineTimeconfig", _this.machineTime);
                console.info(_this.machineTime);
                _this.saveProductdata();
            });
        });
    }
    HeaderinfoComponent.prototype.textmodel = function () {
        var _this = this;
        if (this.productimodel) {
            if (this.machineStatus === 6) {
                this.showMessageBox(browserWindow, {
                    type: "warning",
                    message: "确定启动空跑模式？？？",
                    buttons: ["确定", "取消"],
                    defaultId: 0,
                    cancelId: -1,
                }).then(function (btnIndex) {
                    if (btnIndex === 0) {
                        _this.productclass = [true, false];
                        _this.ipcService.send("runModel", { code: 0 });
                        _this.runstyle = true;
                    }
                    else {
                        _this.productimodel = true;
                    }
                });
            }
            else {
                this.showMessageBox(browserWindow, {
                    type: "warning",
                    message: "不是在就绪状态下，不可操作",
                });
                return;
            }
            this.productimodel = false;
        }
        else {
        }
    };
    HeaderinfoComponent.prototype.productmodel = function () {
        var _this = this;
        if (this.runstyle) {
            this.showMessageBox(browserWindow, {
                type: "warning",
                message: "确定启动生产模式？？？",
                buttons: ["确定", "取消"],
                defaultId: 0,
                cancelId: -1,
            }).then(function (btnIndex) {
                if (btnIndex === 0) {
                    _this.productclass = [false, true];
                    _this.ipcService.send("runModel", { code: 1 });
                    _this.productimodel = true;
                }
                else {
                    _this.runstyle = true;
                }
            });
            this.runstyle = false;
        }
    };
    HeaderinfoComponent.prototype.startUp = function () {
        if (this.planproductnum <= 0) {
            this.showMessageBox(browserWindow, {
                type: "warning",
                message: "计划生产个数不能为0",
            });
            return;
        }
        this.ipcService.send("sendPlanProduct", { "planProduct": this.planproductnum });
        this.styleclass = [false, false, false, true, false, false, false, false];
        this.ipcService.send("operate", {
            "code": 1
        });
    };
    HeaderinfoComponent.prototype.repair = function () {
        // if(this.opsStatus===8||this.opsStatus===4){
        //   return;
        // }
        if (this.protecttime === '保养中' || this.opsStatus === 8 || this.opsStatus === 4) {
            return;
        }
        this.isrepaire = true;
        this.ismatain = false;
        if (this.repairtime === "维修") {
            this.repairtime = "维修中";
            this.repairstartTime = Date.now();
        }
        else {
            this.repairtime = "维修";
            this.repairtotaltime = (Date.now() - this.repairstartTime) / 1000;
            this.repairAlltime += this.repairtotaltime;
        }
    };
    HeaderinfoComponent.prototype.matain = function () {
        if (this.repairtime === "维修中" || this.opsStatus === 8 || this.opsStatus === 4) {
            return;
        }
        this.ismatain = true;
        this.isrepaire = false;
        if (this.protecttime === "保养") {
            this.protecttime = "保养中";
            this.matainstarttime = Date.now();
        }
        else {
            this.protecttime = "保养";
            this.mataintotaltime = (Date.now() - this.matainstarttime) / 1000;
            this.matainAlltime += this.mataintotaltime;
        }
    };
    HeaderinfoComponent.prototype.emergencyStop = function () {
        var _this = this;
        this.showMessageBox(browserWindow, {
            type: "warning",
            message: "确定停止吗？？？",
            buttons: ["确定", "取消"],
            defaultId: 0,
            cancelId: -1,
        }).then(function (btnIndex) {
            if (btnIndex === 0) {
                _this.styleclass = [false, false, false, false, false, false, true, false];
                if (_this.opsStatus !== 8 || _this.repairtime === "维修中" || _this.protecttime === "保养中") {
                    return;
                }
                _this.ipcService.send("operate", {
                    "code": 4
                });
            }
            else {
            }
        });
    };
    HeaderinfoComponent.prototype.saveProductdata = function () {
        this.repairstartTime = Date.now();
        this.matainstarttime = Date.now();
        this.matainAlltime = 0;
        this.repairAlltime = 0;
    };
    HeaderinfoComponent.prototype.reset = function () {
        if (this.repairtime === "维修中" || this.protecttime === "保养中") {
            return;
        }
        this.styleclass = [false, false, false, false, true, false, false, false];
        this.ipcService.send("operate", {
            "code": 3
        });
    };
    HeaderinfoComponent.prototype.suspend = function () {
        this.styleclass = [false, false, false, false, false, true, false, false];
        if (this.repairtime === "维修中" || this.protecttime === "保养中") {
            return;
        }
        this.issuspend = !this.issuspend;
        if (this.issuspend) {
            if (this.opsStatus !== 7) {
                return;
            }
        }
        else {
            if (this.opsStatus !== 8) {
                return;
            }
        }
        this.ipcService.send("operate", {
            "code": 2
        });
    };
    // this.opreatelist.push(0);
    // if (this.opreatelist.length % 2 == 0) {
    //   if(this.opsStatus!==7){
    //    return;
    //   }    
    // } else {
    //   if(this.opsStatus!==8){
    //     return;
    //    }
    // }
    // this.ipcService.send("operate", {
    //   "code": 2
    // })
    // }
    HeaderinfoComponent.prototype.getStatus = function (data) {
        this.opsStatus = data;
    };
    HeaderinfoComponent.prototype.showIo = function () {
        if (this.userinformation.role == "操作员") {
            return;
        }
        this.ioisShow.emit(this.isShow);
    };
    HeaderinfoComponent.prototype.showConfig = function () {
        this.styleclass = [false, false, true, false, false, false, false, false];
        // if(this.userinformation.role=="操作员"){
        //   return;
        // }
        this.configisShow.emit(this.iscongigshow);
    };
    HeaderinfoComponent.prototype.openLogPanel = function () {
        this.styleclass = [false, true, false, false, false, false, false, false];
        this.isUseShow = true;
        this.isUseShowfun.emit(this.isUseShow);
    };
    HeaderinfoComponent.prototype.loginoutin = function () {
        this.styleclass = [false, false, false, false, false, false, false, true];
        if (this.showloginout === true) {
            this.showloginout = false;
        }
        else {
            this.showloginout = true;
        }
    };
    HeaderinfoComponent.prototype.changpwd = function () {
        this.changepassword.emit(true);
    };
    HeaderinfoComponent.prototype.loginin = function () {
        if (this.userinformation.isLogin === false) {
            this.loginstatus = "登录";
            this.outlogin.emit(false);
        }
        else {
            if (this.machineStatus === 8 || this.machineStatus === 4) {
                return;
            }
            this.loginstatus = "退出登录";
            this.ipcService.send("UserLogin", { "username": "", "psw": "", "code": 0 }); //0代表退出
            this.isloginPanelShow.emit(false);
        }
    };
    HeaderinfoComponent.prototype.logout = function () {
        this.isloginPanelShow.emit(false);
    };
    HeaderinfoComponent.prototype.openpointPanel = function () {
        if (this.userinformation.role == "操作员") {
            return;
        }
        this.ispointPanelShow.emit(this.pointShow);
    };
    HeaderinfoComponent.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    HeaderinfoComponent.prototype.changePwd = function () {
        this.ischangepwdPanelShow.emit(false);
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", headerinfo_1.Headerinfo)
    ], HeaderinfoComponent.prototype, "headerinfo", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], HeaderinfoComponent.prototype, "planproductnum", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], HeaderinfoComponent.prototype, "goodnumber", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], HeaderinfoComponent.prototype, "CTendtime", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], HeaderinfoComponent.prototype, "failnumber", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], HeaderinfoComponent.prototype, "machineStatus", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "configinfomation", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Array)
    ], HeaderinfoComponent.prototype, "logs", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "userinformation", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "ioisShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "configisShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "isUseShowfun", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "ispointPanelShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "isloginPanelShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "ischangepwdPanelShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "changepassword", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "outlogin", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "runmodel", void 0);
    HeaderinfoComponent = __decorate([
        core_1.Component({
            selector: 'headinfo',
            templateUrl: "./webApp/component/headerinfo/headerinfo.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], HeaderinfoComponent);
    return HeaderinfoComponent;
}());
exports.HeaderinfoComponent = HeaderinfoComponent;
//# sourceMappingURL=headerinfo.js.map