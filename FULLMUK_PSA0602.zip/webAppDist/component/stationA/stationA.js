"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var dialog = nodeRequire('electron').remote.dialog;
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var StationA = /** @class */ (function () {
    function StationA(_ngZone, ipcService) {
        this.isShow = true;
        this.pointshow = true;
        this.stationAshow = false;
        this.stationBshow = true;
        this.configisShow = new core_1.EventEmitter();
        this.configinfos = new core_1.EventEmitter();
        this.iscongigshow = true;
        this.SAVE_PATH = "D:/ShopFlow/assemble.ini";
        this.startclass = false;
        this.ioisShow = new core_1.EventEmitter();
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.showFlag = [true, false];
        this.config = {
            Ip: "mic139.wistron.com",
            Station: "UF1",
            StationID: "WIZS_TB1-1FT-02_01_UF1",
            StationNo: "UF1",
            MAC_ADDR: "00-1B-21-13-12-47",
            line: "TB1-1FT-01",
            version: "X1-FULLMUK PSA-2017/11/22",
            stage: "UF",
            planCT: "36",
        };
        this.configs = {
            Ip: "",
            Station: "",
            StationID: "",
            StationNo: "",
            MAC_ADDR: "",
            line: "",
            version: "",
            planCT: "",
            stage: "",
        };
        this.ipcService = ipcService;
        this.machinestatus = 0;
        this.clickclass = [false, false];
    }
    StationA.prototype.ngOnInit = function () {
        var _this = this;
        this.ipcService.on("getconfigResult", function (data) {
            _this._ngZone.run(function () {
                if (data.data.code === 1) {
                    _this.showMessageBox(browserWindow, {
                        type: "warning",
                        message: "保存成功",
                        defaultId: 0,
                        cancelId: -1,
                    });
                }
                else {
                    _this.showMessageBox(browserWindow, {
                        type: "warning",
                        message: "保存失败"
                    });
                }
            });
        });
    };
    StationA.prototype.getuserrole = function (role) {
        this.userrole = role;
    };
    StationA.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    StationA.prototype.getstatus = function (data) {
        this.machinestatus = data;
    };
    StationA.prototype.saveConfig = function () {
        var _this = this;
        this.clickclass = [true, false];
        this.showMessageBox(browserWindow, {
            type: "warning",
            message: "是否保存",
            buttons: ["确定", "取消"],
            defaultId: 0,
            cancelId: -1,
        }).then(function (btnIndex) {
            if (btnIndex === 0) {
                _this.ipcService.send("machineconfigOnly", _this.config);
                _this.configinfos.emit([_this.config.StationID, _this.config.StationNo, _this.config.version, _this.config.planCT, _this.config.line]);
            }
            else {
                _this.cancel();
            }
        });
    };
    StationA.prototype.readmachineconfigs = function (data) {
        if (data !== undefined && data !== "") {
            this.config = data;
            this.configs = data;
            if (this.config.Ip === "") {
                this.config.Ip = "mic139.wistron.com";
            }
            if (this.config.Station === "") {
                this.config.Station = "UF1";
            }
            if (this.config.StationID === "") {
                this.config.StationID = "WIZS_TB1-1FT-02_01_UF1";
            }
            if (this.config.StationNo === "") {
                this.config.StationNo = "UF1";
            }
            if (this.config.MAC_ADDR === "") {
                this.config.MAC_ADDR = "00-1B-21-13-12-47";
            }
            if (this.config.line === "") {
                this.config.line = "TB1-1FT-01";
            }
            if (this.config.version === "") {
                this.config.version = "X1-FULLMUK PSA-2017/11/22";
            }
            if (this.config.planCT === "") {
                this.config.planCT = "36";
            }
            if (this.config.stage === "") {
                this.config.stage = "UF";
            }
        }
    };
    StationA.prototype.cancel = function () {
        var _this = this;
        this.clickclass = [false, true];
        this.ipcService.send("pageready", {});
        setTimeout(function () {
            _this.ipcService.on("machineconfig", function (data) {
                _this._ngZone.run(function () {
                    _this.configs = data.data.config;
                });
            });
        }, 1000);
        this.config = this.configs;
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], StationA.prototype, "configisShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], StationA.prototype, "configinfos", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], StationA.prototype, "ioisShow", void 0);
    StationA = __decorate([
        core_1.Component({
            selector: 'station-a',
            templateUrl: "./webApp/component/stationA/stationA.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], StationA);
    return StationA;
}());
exports.StationA = StationA;
//# sourceMappingURL=stationA.js.map