"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var assembling_1 = require("../../common/bean/assembling");
var ipc_service_1 = require("../../common/service/ipc.service");
var headerinfo_1 = require("../../common/bean/headerinfo");
var dialog = nodeRequire('electron').remote.dialog;
var AssembleinfoComponent = /** @class */ (function () {
    function AssembleinfoComponent(_ngZone, ipcService) {
        var _this = this;
        this.sendGoodnumber = new core_1.EventEmitter();
        this.sendfailnumber = new core_1.EventEmitter();
        this.sendProTime = new core_1.EventEmitter();
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.ipcService = ipcService;
        this.presicionArrary = [0, 0, 0];
        this.checkinfo = [0, 0, 0];
        this.successinfo = "";
        this.goodnumber = 0;
        this.ctnumber = [];
        this.ctstarttime = 0;
        this.ctendtime = 0;
        this.failnumber = 0;
        // this.configinfos.proTime=15000;
        this.configinfos = new configinfo();
        // this.ipcService.on("finishResult", (data) => {
        //   this._ngZone.run(() => {
        //     if(data.data.code!==""&&data.data.code===1){
        //       this.successinfo="OK";
        //       this.goodnumber+=1;
        //       this.ctstarttime = Date.now(); 
        //       this.ctnumber.push(this.ctstarttime);
        //       if (this.ctnumber.length >= 2) {
        //           this.ctendtime =(this.ctnumber[this.ctnumber.length-1] - this.ctnumber[this.ctnumber.length-2])/1000;//CT计数         
        //       }
        //       this.sendGoodnumber.emit([this.goodnumber,this.ctendtime]);
        //     }else{
        //       this.successinfo="NG";
        //       this.failnumber+=1;
        //       this.sendfailnumber.emit(this.failnumber);
        //     }
        //   });
        // });
        this.ipcService.on("checkinfoResult", function (data) {
            _this._ngZone.run(function () {
                if (data.data.checkinfoXinfo !== "" && data.data.checkinfoXinfo != undefined) {
                    _this.checkinfo[0] = data.data.checkinfoXinfo;
                    _this.checkinfo[1] = data.data.checkinfoYinfo;
                    _this.checkinfo[2] = data.data.checkinfoAngleinfo;
                }
                else {
                    _this.showMessageBox({
                        type: "warning",
                        message: "获取复检信息失败"
                    });
                    return;
                }
            });
        });
        this.ipcService.on("precisionResult", function (data) {
            _this._ngZone.run(function () {
                if (data.data.precisionXinfo) {
                    _this.presicionArrary[0] = data.data.precisionXinfo;
                    _this.presicionArrary[1] = data.data.precisionYinfo;
                    _this.presicionArrary[2] = data.data.precisionAngleinfo;
                }
                else {
                    _this.showMessageBox({
                        type: "warning",
                        message: "获取贴合精度失败"
                    });
                    return;
                }
            });
        });
    }
    AssembleinfoComponent.prototype.ngOnInit = function () {
        this.sendProTime.emit(this.configinfos.proTime);
    };
    AssembleinfoComponent.prototype.changeconfig = function () {
        this.sendProTime.emit(this.configinfos.proTime);
        this.ipcService.send("setParagram", this.configinfos);
    };
    AssembleinfoComponent.prototype.showMessageBox = function (options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], AssembleinfoComponent.prototype, "sendGoodnumber", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], AssembleinfoComponent.prototype, "sendfailnumber", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], AssembleinfoComponent.prototype, "sendProTime", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", assembling_1.Assembling)
    ], AssembleinfoComponent.prototype, "assembling", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", headerinfo_1.Headerinfo)
    ], AssembleinfoComponent.prototype, "headerinfo", void 0);
    AssembleinfoComponent = __decorate([
        core_1.Component({
            selector: 'assemble-info',
            templateUrl: "./webApp/component/assembleing/assembleing.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], AssembleinfoComponent);
    return AssembleinfoComponent;
}());
exports.AssembleinfoComponent = AssembleinfoComponent;
var configinfo = /** @class */ (function () {
    function configinfo() {
        this.precisionXinfo = 0; //贴合精度
        this.precisionYinfo = 0;
        this.precisionAngleinfo = 0;
        this.offsetXinfo = 0; //补偿
        this.offsetYinfo = 0;
        this.offsetAngleinfo = 0;
        this.proTime = 15000;
    }
    return configinfo;
}());
//# sourceMappingURL=assembleing.js.map