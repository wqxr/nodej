"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var dialog = nodeRequire('electron').remote.dialog;
var path = nodeRequire('path');
var fs = nodeRequire('fs');
var iconv = nodeRequire('iconv-lite');
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var LogPanel = /** @class */ (function () {
    function LogPanel(_ngZone) {
        this.islogUseShow = true;
        this.logpanelisShow = new core_1.EventEmitter();
        this.display = "none";
        this.lastDir = null;
        this.rowArray = [];
        this._ngZone = _ngZone;
    }
    LogPanel.prototype.ngOnInit = function () {
    };
    LogPanel.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    LogPanel.prototype.show = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.rowArray = [];
            var dir = "";
            if (_this.lastDir !== null) {
                dir = _this.lastDir;
            }
            else {
                dir = path.join("D:/recheckData/logs/日志记录");
            }
            var options = {
                title: "选择日志文件",
                defaultPath: dir,
                properties: ["openFile"],
            };
            dialog.showOpenDialog(options, function (filePaths) {
                if (!filePaths) {
                    _this.logpanelisShow.emit(_this.islogUseShow);
                    // reject();
                    return;
                }
                else {
                    fs.readFile(filePaths[0], function (err, data) {
                        if (err) {
                            reject(err);
                            return;
                        }
                        _this._ngZone.run(function () {
                            data = iconv.decode(data, "GBK");
                            _this.content = data;
                            var rowList = _this.content.split("\r\n");
                            rowList.forEach(function (rowItem) {
                                _this.rowArray.push(rowItem.split(","));
                            });
                            _this.lastDir = path.join(filePaths[0], "..");
                        });
                        resolve(!_this.islogUseShow);
                    });
                }
            });
        });
    };
    LogPanel.prototype.onclose = function () {
        var _this = this;
        this.showMessageBox(browserWindow, {
            type: "warning",
            message: "是否关闭窗口",
            buttons: ["确定", "取消"],
            defaultId: 0,
            cancelId: -1,
        }).then(function (btnIndex) {
            if (btnIndex === 0) {
                _this.logpanelisShow.emit(_this.islogUseShow);
            }
            else {
            }
        });
    };
    LogPanel.prototype.hidden = function () {
        this.display = "none";
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], LogPanel.prototype, "logpanelisShow", void 0);
    LogPanel = __decorate([
        core_1.Component({
            selector: 'log-panel',
            templateUrl: "./webApp/component/logPanel/logPanel.html",
        }),
        __metadata("design:paramtypes", [core_1.NgZone])
    ], LogPanel);
    return LogPanel;
}());
exports.LogPanel = LogPanel;
//# sourceMappingURL=logPanel.js.map