"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var stationA_1 = require("../stationA/stationA");
var stationB_1 = require("../stationB/stationB");
var savepoint_1 = require("../savepoint/savepoint");
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var dialog = nodeRequire('electron').remote.dialog;
var AsideComponent = /** @class */ (function () {
    function AsideComponent(_ngZone, ipcService) {
        this.pointshow = true;
        this.stationAshow = false;
        this.stationBshow = true;
        this.openIOshow = true;
        this.configShow = true;
        this.openteacherPoint = true;
        this.configinfo = {
            configname: "",
            configid: "",
            version: "",
            planCT: "",
            line: "",
        };
        this.configisShow = new core_1.EventEmitter();
        this.configinfos = new core_1.EventEmitter();
        this.sendProtime = new core_1.EventEmitter();
        this.iscongigshow = true;
        this.SAVE_PATH = "D:/ShopFlow/assemble.ini";
        this.startclass = false;
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.showFlag = [true, false, false, false];
        //  console.log(_.isString(this.title));
        this.config = {
            Ip: "mic139.wistron.com",
            Station: "UF1",
            StationID: "WIZS_TB1-1FT-02_01_UF1",
            StationNo: "UF1",
            MAC_ADDR: "00-1B-21-13-12-47",
            line: "TB1-1FT-01",
            version: "X1-FULLMUK PSA-2017/11/22",
            planCT: "36",
        };
        this.ipcService = ipcService;
    }
    AsideComponent.prototype.showconfiginfo = function (stationname) {
        this.configinfo.configname = stationname[1];
        this.configinfo.configid = stationname[0];
        this.configinfo.version = stationname[2];
        this.configinfo.planCT = stationname[3];
        this.configinfo.line = stationname[4];
        //this.configShow=true;
        this.configinfos.emit(stationname);
    };
    AsideComponent.prototype.maskhidden = function (mask) {
        this.configisShow.emit(this.iscongigshow);
    };
    AsideComponent.prototype.showProTime = function (protime) {
        this.protimenumber = protime[0];
        this.sendProtime.emit(protime);
    };
    AsideComponent.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    AsideComponent.prototype.onclose = function () {
        var _this = this;
        this.showMessageBox(browserWindow, {
            type: "warning",
            message: "是否关闭窗口",
            buttons: ["确定", "取消"],
            defaultId: 0,
            cancelId: -1,
        }).then(function (btnIndex) {
            if (btnIndex === 0) {
                _this.configisShow.emit(true);
                _this.ipcService.send("openIOPanel", { "code": 0 });
                //this.iscongigshow=!this.iscongigshow;
            }
            else {
            }
        });
    };
    AsideComponent.prototype.openStationA = function () {
        this.stationAshow = false;
        this.stationBshow = true;
        this.showFlag = [true, false, false, false];
        this.openIOshow = true;
        this.openteacherPoint = true;
        this.ipcService.send("openIOPanel", { "code": 0 });
    };
    AsideComponent.prototype.openstationB = function () {
        this.stationBshow = false;
        this.stationAshow = true;
        this.openIOshow = true;
        this.showFlag = [false, true, false, false];
        this.openteacherPoint = true;
        this.ipcService.send("openIOPanel", { "code": 0 });
    };
    AsideComponent.prototype.openIOpanel = function () {
        this.stationAshow = true;
        this.stationBshow = true;
        this.openIOshow = false;
        this.openteacherPoint = true;
        this.showFlag = [false, false, true, false];
        this.ipcService.send("openIOPanel", { "code": 1 });
    };
    AsideComponent.prototype.openTeacher = function () {
        this.stationAshow = true;
        this.stationBshow = true;
        this.openIOshow = true;
        this.openteacherPoint = false;
        this.showFlag = [false, false, false, true];
        this.ipcService.send("openIOPanel", { "code": 0 });
    };
    AsideComponent.prototype.readmachineconfig = function (data) {
        if (data === "") {
            this.stationA.readmachineconfigs(this.config);
        }
        else if (data !== undefined && data !== "") {
            this.config = data;
            this.stationA.readmachineconfigs(this.config);
        }
    };
    AsideComponent.prototype.readPressInfo = function (data) {
        // window.setTimeout(()=>{
        if (data !== undefined && data !== "") {
            this.stationB.readconfigs(data);
        }
        //},1000)
        //this.stationB.readconfigs(data);
    };
    AsideComponent.prototype.getmachineStatus = function (data) {
        this.stationA.getstatus(data);
        this.stationB.getstatus(data);
        this.savepoint.getstatus(data);
    };
    AsideComponent.prototype.getuserRole = function (role) {
        if (role === "admin") {
            this.userrole = 1;
        }
        else {
            this.userrole = 2;
        }
        this.stationA.getuserrole(this.userrole);
        this.stationB.getuserrole(this.userrole);
        this.savepoint.getuserrole(this.userrole);
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], AsideComponent.prototype, "configisShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], AsideComponent.prototype, "configinfos", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], AsideComponent.prototype, "sendProtime", void 0);
    __decorate([
        core_1.ViewChild(stationA_1.StationA),
        __metadata("design:type", stationA_1.StationA)
    ], AsideComponent.prototype, "stationA", void 0);
    __decorate([
        core_1.ViewChild(savepoint_1.SavePointComponent),
        __metadata("design:type", savepoint_1.SavePointComponent)
    ], AsideComponent.prototype, "savepoint", void 0);
    __decorate([
        core_1.ViewChild(stationB_1.StationB),
        __metadata("design:type", stationB_1.StationB)
    ], AsideComponent.prototype, "stationB", void 0);
    AsideComponent = __decorate([
        core_1.Component({
            selector: 'config-panel',
            templateUrl: "./webApp/component/aside/aside.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], AsideComponent);
    return AsideComponent;
}());
exports.AsideComponent = AsideComponent;
//# sourceMappingURL=aside.js.map