"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var headerinfo_1 = require("../../common/bean/headerinfo");
var ECharts = require("echarts");
var dialog = nodeRequire('electron').remote.dialog;
var fs = nodeRequire('fs');
var LeftInfoComponent = /** @class */ (function () {
    function LeftInfoComponent(_ngZone, ipcService, elementRef) {
        var _this = this;
        this.top = 0;
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.ipcService = ipcService;
        this.elementRef = elementRef;
        this.valueList = [];
        this.dateList = [];
        this.presicionArrary = [0, 0, 0];
        this.checkinfo = [0, 0, 0];
        this.bgetpress = false;
        this.ipresstime = 0;
        this.ydatalist = [];
        this.styleclass = [false, false, false];
        this.imgstring = "";
        this.shopflowStaus = "";
        this.SFCmessage = "";
        this.SNsearch = [false, false, false];
        this.communciateStatus = {
            emengencyclass: false,
            safedoorclass: false,
            gunclass: false,
            pressclass: false,
            ccdclass: false,
        };
        // this.images = [];
        //this.initLanguageChart();
        //shopflow上传状态
        this.ipcService.on("shopflowStatus", function (data) {
            _this._ngZone.run(function () {
                if (data.data.code === 1) {
                    _this.shopflowStaus = "OK";
                }
                else {
                    _this.shopflowStaus = "NG";
                }
            });
        });
        this.ipcService.on("SFCmessage", function (data) {
            _this._ngZone.run(function () {
                _this.SFCmessage = data.data.message;
            });
        });
        this.ipcService.on("TensionInfo", function (data) {
            _this._ngZone.run(function () {
                if (data.data.operate == "stop") {
                    _this.bgetpress = false;
                    _this.valueList.push(data.data.data);
                    _this.updateLine(_this.valueList);
                }
                else {
                    _this.option.title[0].text = data.data.operate;
                    _this.getPressSN = _this.option.title[0].text;
                    if (!_this.bgetpress) {
                        _this.bgetpress = true;
                        _this.valueList = [];
                    }
                    else {
                        _this.valueList.push(data.data.data);
                        _this.updateLine(_this.valueList);
                    }
                }
            });
        });
        this.ipcService.on("precisionResult", function (data) {
            _this._ngZone.run(function () {
                if (data.data.precisionXinfo) {
                    _this.presicionArrary[0] = data.data.precisionXinfo;
                    _this.presicionArrary[1] = data.data.precisionYinfo;
                    _this.presicionArrary[2] = data.data.precisionAngleinfo;
                }
                else {
                    _this.showMessageBox({
                        type: "warning",
                        message: "获取贴合精度失败"
                    });
                    return;
                }
            });
        });
        this.ipcService.on("checkinfoResult", function (data) {
            _this._ngZone.run(function () {
                if (data.data.checkinfoXinfo !== "" && data.data.checkinfoXinfo != undefined) {
                    _this.checkinfo[0] = data.data.checkinfoXinfo;
                    _this.checkinfo[1] = data.data.checkinfoYinfo;
                    _this.checkinfo[2] = data.data.checkinfoAngleinfo;
                }
                else {
                    _this.showMessageBox({
                        type: "warning",
                        message: "获取复检信息失败"
                    });
                    return;
                }
            });
        });
        this.ipcService.on("communicateStatus", function (data) {
            _this._ngZone.run(function () {
                if (data.data.code === 0) {
                    _this.communciateStatus.emengencyclass = true;
                }
                else if (data.data.code === 1) {
                    if (data.data.data === 1) {
                        _this.communciateStatus.safedoorclass = true;
                    }
                    else {
                        _this.communciateStatus.safedoorclass = false;
                    }
                }
                else if (data.data.code === 2) {
                    if (data.data.data === 1) {
                        _this.communciateStatus.gunclass = true;
                    }
                    else {
                        _this.communciateStatus.gunclass = false;
                    }
                }
                else if (data.data.code === 3) {
                    if (data.data.data === 1) {
                        _this.communciateStatus.pressclass = true;
                    }
                    else {
                        _this.communciateStatus.pressclass = false;
                    }
                }
                else if (data.data === 4) {
                    if (data.data.data === 1) {
                        _this.communciateStatus.ccdclass = true;
                    }
                    else {
                        _this.communciateStatus.ccdclass = false;
                    }
                }
            });
        });
        this.option = {
            //Make gradient line here
            visualMap: [{
                    show: false,
                    type: 'continuous',
                    seriesIndex: 0,
                    min: 0,
                    max: 150
                }, {
                    show: false,
                    type: 'continuous',
                    seriesIndex: 0,
                    dimension: 0,
                    min: 0,
                    max: this.dateList.length + 10
                }],
            title: [{
                    left: 'center',
                    text: '',
                }, {}],
            tooltip: {
                trigger: 'axis'
            },
            xAxis: [{
                    data: []
                }, {}],
            yAxis: [{
                    splitLine: { show: true },
                    data: []
                }, {}],
            grid: [
                {
                    left: '15%',
                    bottom: '12%'
                }
            ],
            series: [{
                    type: 'line',
                    showSymbol: false,
                }, {
                    type: 'line',
                    showSymbol: false,
                    data: this.valueList,
                    //xAxisIndex: 1,
                    yAxisIndex: 1
                }],
        };
    }
    // ngAfterViewInit() { // 模板中的元素已创建完成
    //   this.initLanguageChart();
    // }
    LeftInfoComponent.prototype.showMessageBox = function (options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    LeftInfoComponent.prototype.initLanguageChart = function () {
        var div = this.elementRef.nativeElement.querySelector(".charts");
        this.chart = ECharts.init(div);
        // console.info(this.pressure.length)
        this.chart.setOption(this.option);
    };
    LeftInfoComponent.prototype.updateLine = function (data) {
        if (undefined === this.chart) {
            return;
        }
        this.option.series[0].data = data;
        //this.option.xAxis[0].data=this.dateList;
        //this.option.yAxis[0].data=this.ydatalist;
        this.chart.setOption(this.option);
    };
    // window.setTimeout(() => {
    //   ngAfterViewInit();
    // },3000);
    LeftInfoComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        setTimeout(function () {
            if (_this.protime > 1000) {
                _this.protime = _this.protime / 1000;
                for (var i = 0; i < (_this.protime + 15); i++) {
                    _this.dateList.push(i);
                }
            }
            _this.pressdatainfo = _this.pressdatainfo / 1;
            for (var i = 0; i < (_this.pressdatainfo + 15); i++) {
                _this.ydatalist.push(i);
            }
            // console.info(this.pressdatainfo);
            // console.info(this.pressdatainfo+20);
            _this.option.visualMap[0].max = _this.pressdatainfo + 15;
            _this.option.xAxis[0].data = _this.dateList;
            _this.option.yAxis[0].data = _this.ydatalist;
            _this.initLanguageChart();
        }, 100);
    };
    LeftInfoComponent.prototype.switchtype = function (type) {
        if (type === 0) {
            this.ipcService.send("typeStatus", { type: 0 }); //ansi
            this.styleclass = [true, false, false];
        }
        else if (type === 1) {
            this.ipcService.send("typeStatus", { type: 1 }); //iso
            this.styleclass = [false, true, false];
        }
        else if (type === 2) {
            this.ipcService.send("typeStatus", { type: 2 }); //jis
            this.styleclass = [false, false, true];
        }
    };
    LeftInfoComponent.prototype.searchSNinfo = function () {
        this.SNsearch = [true, false, false];
        if (this.searchSN.length === undefined) {
            return;
        }
        if (this.searchSN.length < 10) {
            this.showMessageBox({
                type: "warning",
                message: "条码读取错误，请重新输入",
            });
            return;
        }
        else {
            this.ipcService.send("CheckSN", { "type": 0, "SN": this.searchSN, }); //查询SFC
        }
    };
    LeftInfoComponent.prototype.putSMT = function () {
        this.SNsearch = [false, true, false];
        if (this.searchSN.length === undefined) {
            return;
        }
        if (this.searchSN.length < 10) {
            this.showMessageBox({
                type: "warning",
                message: "条码读取错误，请重新输入",
            });
            return;
        }
        else {
            this.ipcService.send("CheckSN", { "type": 1, "SN": this.searchSN, }); //上传SMT
        }
    };
    LeftInfoComponent.prototype.putSFC = function () {
        this.SNsearch = [false, false, true];
        if (this.searchSN.length === undefined) {
            return;
        }
        if (this.searchSN.length < 10) {
            this.showMessageBox({
                type: "warning",
                message: "条码读取错误，请重新输入",
            });
            return;
        }
        else {
            this.ipcService.send("CheckSN", { "type": 2, "SN": this.searchSN, }); //上传sfc
        }
    };
    LeftInfoComponent.prototype.setImages = function (sn, times) {
        var _this = this;
        var day = "";
        var month = "";
        this.images = [];
        if (new Date().getDate() < 10) {
            day = "0" + new Date().getDate();
        }
        else {
            day = new Date().getDate().toString();
        }
        if ((new Date().getMonth() + 1) < 10) {
            month = "0" + (new Date().getMonth() + 1);
        }
        else {
            month = (new Date().getMonth() + 1).toString();
        }
        var now = new Date().getFullYear() + month + day;
        var nowtime = new Date().getSeconds();
        this.imgstring = "E:/Cognex/2. Images/Jpg" + now + "/" + sn;
        fs.readdir(this.imgstring, function (err, files) {
            if (err) {
                return;
            }
            else if (files.length >= times * 2) {
                for (var i = 0; i < files.length; i++) {
                    if (i >= (times - 1) * 2 && i < 2 * times) {
                        _this.images.push(_this.imgstring + "/" + files[i]);
                    }
                }
                for (var i = 0; i < _this.images.length; i++) {
                    var repl = new RegExp("\\\\", "g");
                    var path = encodeURI(_this.images[i].replace(repl, '//'));
                    _this.images[i] = "url(" + path + ")";
                }
                return;
            }
        });
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", String)
    ], LeftInfoComponent.prototype, "successinfo", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Array)
    ], LeftInfoComponent.prototype, "logs", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], LeftInfoComponent.prototype, "protime", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], LeftInfoComponent.prototype, "pressdatainfo", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", headerinfo_1.Headerinfo)
    ], LeftInfoComponent.prototype, "headerinfo", void 0);
    LeftInfoComponent = __decorate([
        core_1.Component({
            selector: 'leftInfo',
            templateUrl: "./webApp/component/leftInfo/keycaps.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService, core_1.ElementRef])
    ], LeftInfoComponent);
    return LeftInfoComponent;
}());
exports.LeftInfoComponent = LeftInfoComponent;
//# sourceMappingURL=keycaps.js.map