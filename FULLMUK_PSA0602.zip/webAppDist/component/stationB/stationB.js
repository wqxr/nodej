"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var dialog = nodeRequire('electron').remote.dialog;
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var StationB = /** @class */ (function () {
    function StationB(_ngZone, ipcService) {
        this.isShow = true;
        this.sendProTime = new core_1.EventEmitter();
        this.ioisShow = new core_1.EventEmitter();
        this.iscongigshow = true;
        this._ngZone = _ngZone;
        this.ipcService = ipcService;
        this.title = 'IAStudio';
        this.configs = {
            precisionXinfo: 0,
            precisionYinfo: 0,
            precisionAngleinfo: 0,
            offsetXinfo: 0,
            offsetYinfo: 0,
            offsetAngleinfo: 0,
            proTime: 15000,
            pressdata: 100,
            checkXoffset: 0,
            checkYoffset: 0.02,
            checkAoffset: 0.02,
        };
        this.machinestatus = 0;
        this.clickclass = [false, false];
    }
    StationB.prototype.ngOnInit = function () {
        var _this = this;
        // this.sendProTime.emit([this.configs.proTime,this.configs.pressdata,]);
        this.ipcService.on("getParagramResult", function (data) {
            _this._ngZone.run(function () {
                if (data.data.code === 1) {
                    _this.showMessageBox(browserWindow, {
                        type: "warning",
                        message: "保存成功"
                    });
                    _this.ioisShow.emit(false);
                    return;
                }
                else {
                    _this.showMessageBox(browserWindow, {
                        type: "warning",
                        message: "保存失败"
                    });
                    return;
                }
            });
        });
    };
    StationB.prototype.getstatus = function (data) {
        this.machinestatus = data;
    };
    StationB.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    StationB.prototype.changeconfig = function () {
        var _this = this;
        this.clickclass = [true, false];
        this.showMessageBox(browserWindow, {
            type: "warning",
            message: "是否保存",
            buttons: ["确定", "取消"],
            defaultId: 0,
            cancelId: -1,
        }).then(function (btnIndex) {
            if (btnIndex === 0) {
                var maxcheckinfo = _this.configs.checkAoffset > _this.configs.checkXoffset ? _this.configs.checkAoffset : _this.configs.checkXoffset;
                var maxcorrectcheckinfo = maxcheckinfo > _this.configs.checkYoffset ? maxcheckinfo : _this.configs.checkYoffset;
                _this.sendProTime.emit([_this.configs.proTime, _this.configs.pressdata, maxcorrectcheckinfo]);
                _this.ipcService.send("setParagram", _this.configs);
            }
            else {
                _this.cancel();
            }
        });
    };
    StationB.prototype.readconfigs = function (data) {
        if (data !== undefined && data !== "") {
            this.configs = data;
            var maxcheckinfo = this.configs.checkAoffset > this.configs.checkXoffset ? this.configs.checkAoffset : this.configs.checkXoffset;
            var maxcorrectcheckinfo = maxcheckinfo > this.configs.checkYoffset ? maxcheckinfo : this.configs.checkYoffset;
            // this.sendProTime.emit([this.configs.proTime, this.configs.pressdata,maxcorrectcheckinfo]);
        }
    };
    StationB.prototype.getuserrole = function (role) {
        this.userrole = role;
    };
    StationB.prototype.cancel = function () {
        var _this = this;
        this.clickclass = [false, true];
        this.ipcService.send("pageready", {});
        setTimeout(function () {
            _this.ipcService.on("machineconfig", function (data) {
                _this._ngZone.run(function () {
                    _this.configs = data.data.pressInfo;
                });
            });
        }, 1000);
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], StationB.prototype, "sendProTime", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], StationB.prototype, "ioisShow", void 0);
    StationB = __decorate([
        core_1.Component({
            selector: 'station-b',
            templateUrl: "./webApp/component/stationB/stationB.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], StationB);
    return StationB;
}());
exports.StationB = StationB;
//# sourceMappingURL=stationB.js.map