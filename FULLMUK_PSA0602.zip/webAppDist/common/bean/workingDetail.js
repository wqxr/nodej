"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var workingDetail = /** @class */ (function () {
    function workingDetail() {
    }
    return workingDetail;
}());
exports.workingDetail = workingDetail;
//# sourceMappingURL=workingDetail.js.map