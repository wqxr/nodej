"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Headerinfo = /** @class */ (function () {
    function Headerinfo() {
        this.goodnumber = 1; //良数
        this.badnumber = 0; //不良数
        this.totalnumber = 2; //总数
    }
    return Headerinfo;
}());
exports.Headerinfo = Headerinfo;
//# sourceMappingURL=headerinfo.js.map